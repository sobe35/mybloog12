package com.mybloog.mybloog11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mybloog11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
