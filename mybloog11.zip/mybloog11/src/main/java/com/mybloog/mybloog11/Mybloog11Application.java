package com.mybloog.mybloog11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mybloog11Application {

	public static void main(String[] args) {
		SpringApplication.run(Mybloog11Application.class, args);
	}

}
